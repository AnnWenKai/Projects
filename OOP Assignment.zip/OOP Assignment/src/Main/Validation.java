/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Main;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author user
 */
public class Validation {
    public static boolean isValidContactNum(String contactNo){
        String phoneRegex = "\\d{3}-\\d{7,8}";
        return contactNo.matches(phoneRegex);
    }
    
    public static boolean isValidEmail(String email) {
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@" +
                             "(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        return email.matches(emailRegex);
    }

    public static boolean isValidPassword(String password) {
        if (password.length() < 8) return false;  // minimum length of 8
        if (!password.matches(".*[A-Z].*")) return false;  // at least one uppercase letter
        if (!password.matches(".*[a-z].*")) return false;  // at least one lowercase letter
        if (!password.matches(".*\\d.*")) return false;    // at least one digit
        if (!password.matches(".*[!@#$%^&*].*")) return false; // at least one special character
        return true;
    }
    
    public static boolean usernameExists(String username) {
        try (BufferedReader br = new BufferedReader(new FileReader("user.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] userDetails = line.split(";");
                if (userDetails[0].equals(username)) {
                    return true; // Username already exists
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }
    
}
