/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Student;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JOptionPane;
import Main.User;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import javax.swing.table.DefaultTableModel;
import java.util.ArrayList;
import java.util.List;


public class BookingSchedulePage extends javax.swing.JFrame {
    
    
    public User user;
    /**
     * Creates new form BookingSchedulePage
     */
    public BookingSchedulePage(User user) {
        initComponents();
        this.user = user;
        arrangeSlots();
        loadFutureData();
        hidePastSlots();
    }
    
    public void updatePastTable (String username, String date, String start, String end) {
        javax.swing.table.DefaultTableModel model = (DefaultTableModel)upcomingTable.getModel();
        model.addRow(new Object [] {username, date, start, end});
    }
    
    private void loadFutureData() {
        String filePath = "appointments.txt";
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(";"); // Assuming data is comma-separated
                if (data.length == 5) { // Ensure there are 8 fields to avoid ArrayIndexOutOfBoundsException
                    updatePastTable(data[1], data[2], data[3], data[4]);
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error reading from file: " + e.getMessage());
        }
    }  
    
    private void hidePastSlots() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d-MMMM-y");
        DefaultTableModel model = (DefaultTableModel) upcomingTable.getModel();
        List<Object[]> pastSlots = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader("appointments.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(";");
                if (data.length == 5) { // Ensure valid data format and filter by username
                    try {
                        LocalDate slotDate = LocalDate.parse(data[2], formatter);
                        if (slotDate.isAfter(LocalDate.now()) || slotDate.isEqual(LocalDate.now())) {
                            // Only add future or current dates to the table
                            pastSlots.add(new Object[]{data[1], data[2], data[3], data[4]});
                        }
                    } catch (DateTimeParseException e) {
                        System.err.println("Invalid date format: " + data[1]);
                    }
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error reading from file: " + e.getMessage());
            return;
        }
        
        // Clear the table and add only future slots
        model.setRowCount(0);
        for (Object[] slot : pastSlots) {
            model.addRow(slot);
        }
    }
    
    private void arrangeSlots() {
        String filePath = "appointments.txt";
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d-MMMM-y");
        List<String[]> slotsList = new ArrayList<>();

    // Read and parse data from the file
    try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
        String line;
        while ((line = br.readLine()) != null) {
            String[] data = line.split(";");
            if (data.length >= 5) {
                slotsList.add(data);
            }
        }
    } catch (IOException e) {
        JOptionPane.showMessageDialog(this, "Error reading from file: " + e.getMessage());
        return;
    }

    // Sort slots based on the date
    slotsList.sort((slot1, slot2) -> {
        try {
            LocalDate date1 = LocalDate.parse(slot1[2], formatter);
            LocalDate date2 = LocalDate.parse(slot2[2], formatter);
            return date1.compareTo(date2);
        } catch (DateTimeParseException e) {
            System.err.println("Error parsing dates: " + e.getMessage());
            return 0;
        }
    });

    // Write sorted data back to the file
    try (BufferedWriter bw = new BufferedWriter(new FileWriter(filePath))) {
        for (String[] slot : slotsList) {
            bw.write(String.join(";", slot));
            bw.newLine();
        }
    } catch (IOException e) {
        JOptionPane.showMessageDialog(this, "Error writing to file: " + e.getMessage());
    }
}

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        upcomingTable = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();
        backbtn = new javax.swing.JButton();
        CancelButton = new javax.swing.JButton();
        RescheduleButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("STHupo", 1, 48)); // NOI18N
        jLabel1.setText("Rescheduling");

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/APU_logo.png"))); // NOI18N

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(144, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(33, 33, 33)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.setBackground(new java.awt.Color(229, 229, 255));
        jPanel2.setPreferredSize(new java.awt.Dimension(452, 385));

        jScrollPane1.setViewportView(upcomingTable);
        upcomingTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Lecturer", "Date", "Time Start", "Time End"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });

        upcomingTable.getTableHeader().setReorderingAllowed(false);

        upcomingTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                slotsTableMouseClicked(evt);
            }
        });

        jScrollPane1.setViewportView(upcomingTable);

        jLabel3.setFont(new java.awt.Font("Bradley Hand ITC", 1, 24)); // NOI18N
        jLabel3.setText("Upcoming Bookings");

        backbtn.setBackground(new java.awt.Color(229, 229, 255));
        backbtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/back_icon.png"))); // NOI18N
        backbtn.setBorder(null);
        backbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backbtnActionPerformed(evt);
            }
        });

        CancelButton.setText("Cancel Booking");
        CancelButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CancelButtonActionPerformed(evt);
            }
        });

        RescheduleButton.setText("Reschedule");
        RescheduleButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RescheduleButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 500, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(50, Short.MAX_VALUE))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(150, 150, 150)
                .addComponent(CancelButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(RescheduleButton)
                .addGap(150, 150, 150))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(backbtn)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel3)
                .addGap(190, 190, 190))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(backbtn)
                    .addComponent(jLabel3))
                .addGap(19, 19, 19)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(CancelButton)
                    .addComponent(RescheduleButton))
                .addContainerGap(23, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 600, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void backbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backbtnActionPerformed
        // TODO add your handling code here:
        this.dispose();
        new StudentHomePage(user).setVisible(true);
    }//GEN-LAST:event_backbtnActionPerformed

    private void CancelButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CancelButtonActionPerformed
        // TODO add your handling code here:
        String username = user.getUsername();
        int selectedRow = upcomingTable.getSelectedRow(); // Get the selected row index
        if (selectedRow != -1) {
            // Get the table model
            DefaultTableModel model = (DefaultTableModel) upcomingTable.getModel();

        // Get data from the selected row
            String lecturername = model.getValueAt(selectedRow, 0).toString();
            String date = model.getValueAt(selectedRow, 1).toString();
            String start = model.getValueAt(selectedRow, 2).toString();
            String end = model.getValueAt(selectedRow, 3).toString();

        // Remove the row from the table
            model.removeRow(selectedRow);

        // Read all data from the file
            String filePath = "appointments.txt";
            List<String> fileData = new ArrayList<>();
            try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
                String line;
                while ((line = br.readLine()) != null) {
                    fileData.add(line);
                }
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this, "Error reading file: " + e.getMessage());
                return;
            }

        // Remove the corresponding row from the file data
            String rowToRemove = username + ";" + lecturername + ";"+ date + ";" + start + ";" + end;
            fileData.removeIf(row -> row.equals(rowToRemove));

        // Write the updated data back to the file0
            try (BufferedWriter bw = new BufferedWriter(new FileWriter(filePath))) {
                for (String updatedLine : fileData) {
                    bw.write(updatedLine);
                    bw.newLine();
                }
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this, "Error writing to file: " + e.getMessage());
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select a row to delete.");
        }
    }//GEN-LAST:event_CancelButtonActionPerformed

    private void RescheduleButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RescheduleButtonActionPerformed
        // TODO add your handling code here:
        String username = user.getUsername();
        int selectedRow = upcomingTable.getSelectedRow(); // Get the selected row index
        if (selectedRow != -1) {
        // Get the table model
        DefaultTableModel model = (DefaultTableModel) upcomingTable.getModel();

        // Get data from the selected row
        String lecturer = model.getValueAt(selectedRow, 0).toString();
        String date = model.getValueAt(selectedRow, 1).toString();
        String start = model.getValueAt(selectedRow, 2).toString();
        String end = model.getValueAt(selectedRow, 3).toString();

        // Remove the row from the table
        model.removeRow(selectedRow);

        JOptionPane.showMessageDialog(this, "Booking rescheduled successfully. Please choose a new slot.");
        
        // Remove the corresponding appointment from appointments.txt
        String filePathAppointments = "appointments.txt";
        List<String> fileData = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filePathAppointments))) {
            String line;
            while ((line = br.readLine()) != null) {
                fileData.add(line);
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error reading appointments file: " + e.getMessage());
            return;
        }

        // Remove the selected row from file data
        String rowToRemove = username + ";" + lecturer + ";" + date + ";" + start + ";" + end;
        fileData.removeIf(row -> row.equals(rowToRemove));

        // Write the updated data back to appointments.txt
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(filePathAppointments))) {
            for (String updatedLine : fileData) {
                bw.write(updatedLine);
                bw.newLine();
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error writing to appointments file: " + e.getMessage());
            return;
        }
        
        // Optionally, navigate to the booking page to select a new slot
        this.dispose();
        new Rescheduling(user, lecturer).setVisible(true);
    } else {
        JOptionPane.showMessageDialog(this, "Please select a row to reschedule.");
    }
        
    }//GEN-LAST:event_RescheduleButtonActionPerformed
    private void slotsTableMouseClicked(java.awt.event.MouseEvent evt) {                                         
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(BookingSchedulePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(BookingSchedulePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(BookingSchedulePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(BookingSchedulePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run(User user) {
                new BookingSchedulePage(user).setVisible(true);
            }
            
            @Override
            public void run() {
                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
            } 
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton CancelButton;
    private javax.swing.JButton RescheduleButton;
    private javax.swing.JButton backbtn;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable upcomingTable;
    // End of variables declaration//GEN-END:variables
}
